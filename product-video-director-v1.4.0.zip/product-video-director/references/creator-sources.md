# 公开创作者方法：来源与适用边界

研究日期：2026-10-26；用于 1.2.0。方法见 [工作流选择](generation-workflows.md) 与 [创作者工作方法](creator-workflows.md)，示例见 [本地原创示例](creator-examples.md)。日常使用只需读适用的方法；核对最新能力、出处或适配具体平台时才查当前依据，不要求每次策划都重新联网。

## 怎样使用这份资料

选取有过程说明、失败观察或制作取舍的公开资料，不按粉丝数、播放量或“最强”标题排名。这是有限样本研究，不代表覆盖全部社交平台，也不是对创作者作品质量的独立评奖。

本轮读到的是原作者配套文章、公开帖文和直接访谈；没有播放完整教程或逐帧检查其视频，也没有取得视频字幕。因此只能说“作者在公开文字中说明”，不能说“已观看并复现”。平台介绍用于核对输入机制，不能证明所有账号入口均开放同一能力。

工作方法是对原理的归纳及本项目的可执行化设计，不是原作者逐字教程或统一标准。没有复制长篇提示词、付费内容、工作室模板、代码或演示素材。公开可读不等于 MIT；本包原有五个 MIT 来源和许可证不受本次研究影响。

## 可读正文的创作者来源

| ID | 原作者／原始页面 | 日期与实际阅读范围 | 本次吸收与限制 |
|---|---|---|---|
| C1 | Tim Simmons / Theoretically Media：[The Cinematic Mega Prompt](https://theoreticallymedia.com/blog/cinematic-mega-prompt/)；[配套 YouTube](https://www.youtube.com/watch?v=vRNHNNliDVM) | 原作者文章全文，2026-06-11；YouTube 只核对页面标题 | 同刻多角度选图再动态化。保留方法，不继承固定四格、字符数、写实风格或手持晃动。 |
| C2 | Tim Simmons / Theoretically Media：[The AI Film Studio Update](https://theoreticallymedia.beehiiv.com/p/the-ai-film-studio-update-you-ve-been-waiting-for)；[制作视频](https://www.youtube.com/watch?v=WKO-YgMQhLI) | 原作者通讯全文，2026-09-18；未观看视频、未下载模板 | 按镜头选参考，保存真实提交记录。旋转视频在其案例中用于人工截图选角度，不能泛化为直接输入视频。 |
| C3 | Mable Huang / Curious Refuge：[Hybrid Filmmaking Workflow](https://curiousrefuge.com/blog/how-to-use-ai-in-a-hybrid-filmmaking-workflow) | 公开配套文章全文，2026-09-22（年份由原站教程索引核对） | 分开外观与表演参考，观察旧道具回流。深度参考是可选试验，案例没有证明普遍更优或动作完全一致。 |
| C4 | Mable Huang / Curious Refuge：[Control Camera Movements With Blender and Claude](https://curiousrefuge.com/blog/how-to-control-ai-videos-with-blender-and-claude) | 公开配套文章全文，2026-10-16（年份由原站教程索引核对） | 先修粗预演的动作和运镜，再用于参考；只需空间控制时不必复制僵硬表演。不移植安装或付费平台流程。 |
| C5 | 野菩萨、海信蓝大雨直接访谈：[专访海信×野菩萨，关于AI广告的十个问题](https://www.digitaling.com/articles/1376297.html)，采访 Ruonan、Vera，撰文 Vera | 数英原创访谈正文，2025-07-09，重点 Q5；不是已观看的小红书教程 | 静帧修订后做动态、候选选片、音乐与剪辑补镜迭代。次数、预算、弃用比例及“没有分镜”的表述不作通则。 |
| C6 | Reddit `u/superstarbootlegs`：[18 Free Workflows For Making Short AI Films](https://www.reddit.com/r/comfyui/comments/1lmfmv7/18_free_workflows_for_making_short_ai_films/) | 原帖和作者回复；索引日期 2025-06-28；未检查其成片或工作流文件 | 项目中途升级与后期投入的取舍。工具冲突原因仍是作者推测，不转写成兼容性结论。 |
| C7 | Reddit `u/suaveSavior`：[叙事频道制作流程评论](https://www.reddit.com/r/aitubers/comments/1u6slx5/comment/osepiuu/) | 作者评论全文；原页相对日期，精确日期未独立确认 | 固定场景布局后取多机位，再风格化。案例偏低动作叙事，不据此规定所有项目建模或先做旁白。 |
| C8 | Contra 创作者 Karina：[多角度视频试验及作者回复](https://contra.com/community/ZqsQrgeM-i-wanted-to-test-something-simple) | 原帖及回复；显示 Jan 18，年份未确认；未展开复制截断提示词 | 区分主体一致与场景透视一致，保留未入剪原因。仅有精选成功镜头不能计算成功率。 |

## 官方机制核对

以下只支持相应模式的工作建议；不将页内时长、价格、参考数量或效果宣传固定为本技能能力。

| ID | 官方资料 | 核对范围与适配原则 |
|---|---|---|
| O1 | Runway：[Gen-4 Video Prompting Guide](https://help.runwayml.com/hc/en-us/articles/39789879462419-Gen-4-Video-Prompting-Guide) | 正向运动描述、从必要动作逐项迭代；这是该模式建议，不能推导所有模型禁用负向提示。 |
| O2 | Runway：[Image to Video Prompting Guide](https://help.runwayml.com/hc/en-us/articles/48324313115155-Image-to-Video-Prompting-Guide) | 首图动作线索可与目标相冲突，瑕疵可能进入动态；交互、转变或新增对象仍可能需要外观说明。 |
| O3 | ByteDance Seed：[Introducing Seedance 2.5](https://seed.bytedance.com/en/blog/one-take-creation-flexible-referencing-introducing-seedance-2-5)，2026-07-31 | 阅读多模态参考、白模、定向编辑、延长及即梦入口说明；不继承“完全一致”的宣传或假定所有账号入口支持。 |
| O4 | Kling AI：[Motion Control User Guide](https://kling.ai/quickstart/motion-control-user-guide)，2026-03-05 | 形象与动作参考的取景、朝向和活动空间须相容；面部参考并不自动包含衣物道具。使用前核对实际模式。 |
| O5 | 小云雀：[Web 官方产品手册](https://xyq.jianying.com/tutorials/web-manual)，未列发布日期 | 阅读资产／故事板、Agent 混合参考与片段重拍章节；可按素材、修改对象与时间范围组织任务。故事板管理不等于单次多镜头；章节涉及的模式需按入口核实。 |
| O6 | Runway：[Aleph 2.0 Prompting Guide](https://help.runwayml.com/hc/en-us/articles/52150503729171-Aleph-2-0-Prompting-Guide)，未列发布日期 | 阅读定向编辑、代表画面编辑与按需额外运动说明。编辑图不等于每段首尾图；“保留其他内容”是目标，不是像素级保证。 |
| O7 | Runway：[Multi-Shot Video](https://help.runwayml.com/hc/en-us/articles/51200254894483-Multi-Shot-Video)，未列发布日期 | 阅读 Auto／Custom、输入和运行模式；起始图可选。这是具体应用且使用第三方模型，不外推为所有 Runway 模式。 |
| O8 | Runway：[Performance Capture with Act-Two](https://help.runwayml.com/hc/en-us/articles/42311337895827-Performance-Capture-with-Act-Two)，未列发布日期 | 阅读表演与角色图／视频的分工：角色图与角色视频的身体控制及场景运动处理不同；时长不匹配可能循环。不能统称为任意动作精确迁移。 |

O5–O8 是用户要求更新默认制作方式后补查的官方机制资料。所有页面只阅读可访问文字，未播放示例或登录验证账号，也未进行生成。具体工作流排序是本项目根据保真要求与已有素材作的选择，不是已测出的平台排名。

## 找到但不足以支撑细节归因的线索

| 作者与原链接 | 实际可读范围 | 处理 |
|---|---|---|
| HiShineAi：[九宫格赛车分镜工作流](https://www.bilibili.com/video/BV1xYADzCERe/) | 原站索引简介；直接访问返回 412；索引日期 2026-02-27 | 可确认介绍涉及整组分镜与混合生成路径；不据标题采信“10倍效率”或补造提示词步骤。 |
| 谟音卡卡：[只用即梦的流程拆解](https://www.douyin.com/video/7591863273536949519) | 原站索引配文；直接打开无正文；索引日期 2026-01-05 | 仅作为脚本、图像筛选、动态、剪辑阶段的线索，不声称已读完整教程。 |
| 大师的AI小灶：[提示词越长，AI越笨？](https://jingxuan.douyin.com/m/video/7587225361230974260) | 精选页作者、日期和简介可读，2025-12-24；更细索引摘要来源不明 | 只支持“长度不等于质量”的窄原则；不采纳数值永远无效、风格词一概无用等绝对断言。 |

检索过小红书、X、Instagram，但未取得足以归因具体方法的直接可读原帖。没有用镜像、转载、私信领取材料或绕过登录补齐数量。野菩萨的经验取自直接访谈，不能宣称看过其小红书教程。

## 后续扩充标准

只记录真正读到的内容及访问日；区分原作者说法、平台说明、本项目推导和本地试用结果。新教程与用户事实、满意素材或当前工具能力冲突时，保留事实与锁定条件，选择兼容方法。没有实际生成对照时不宣称提升率或零穿帮；用户带回成片后，才补具体观察与复用条件。
