import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

MODULE = Path(__file__).resolve().parents[1] / "scripts" / "project_store.py"
spec = importlib.util.spec_from_file_location("project_store", MODULE)
store = importlib.util.module_from_spec(spec)
spec.loader.exec_module(store)


def fixture():
    return {"schema_version": "1.0", "project_id": "test-cup", "title": "测试杯", "brief": {"product_facts": ["白杯"]}, "assets": [{"id": "P01", "role": "产品身份"}], "segments": [
        {"id": "C01", "status": "locked", "purpose": "揭示", "duration_seconds": 5,
         "scene": {"name": "白色桌面", "source_kind": "new"},
         "start_state": {"cup": "中央静止"}, "end_state": {"cup": "中央静止"},
         "frames": {"first": {"prompt": "首帧：白色杯子位于桌面中央，把手朝右，左侧晨光。", "reference_ids": ["P01"]}, "keys": [], "last": {"prompt": "尾帧：白色杯子仍在桌面中央，把手朝右，左侧柔光照亮杯体。", "reference_ids": ["P01"]}},
         "video_prompt": "固定机位，杯子不动，左侧光逐渐增亮，最后保持。",
         "transition_out": {"type": "end", "next_segment": None, "notes": "停留后结束"}}
    ]}


def workflow_fixture(workflow="video_edit"):
    plan = fixture()
    plan["schema_version"] = "1.2"
    plan["assets"] = [{"id": "V01", "role": "待剪原片", "path": "media/source.mp4"}]
    segment = plan["segments"][0]
    del segment["frames"]
    del segment["video_prompt"]
    segment.update({"workflow": workflow,
                    "input_assets": [{"asset_id": "V01", "role": "仅保留原片动作与杯体，调整背景亮度"}],
                    "execution_prompt": "编辑 V01：保持杯体、动作和机位，只将背景柔光逐渐增亮，保留完整结束停留。"})
    return plan


class ProjectStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.plan = fixture()
        self.p = self.root / "project.json"
        self.md = self.root / "plan.md"
        self.pdf = self.root / "plan.pdf"
        # Only a format fixture. Production PDF rendering is tested separately.
        self.pdf.write_bytes(b"%PDF-1.4\nfixture\n")

    def tearDown(self):
        self.temp.cleanup()

    def write(self):
        self.p.write_text(json.dumps(self.plan, ensure_ascii=False), encoding="utf-8")
        prompts = []
        for seg in self.plan["segments"]:
            frames = seg.get("frames", {})
            for role in ("first", "last"):
                if role in frames:
                    prompts.append(frames[role]["prompt"])
            prompts.extend(x["prompt"] for x in frames.get("keys", []))
            prompts.extend(seg[field] for field in ("execution_prompt", "video_prompt") if field in seg)
        self.md.write_text("\n\n".join(prompts), encoding="utf-8")

    def save(self, **kwargs):
        self.write()
        return store.save(self.p, self.root / "archive", self.md, self.pdf, "test", **kwargs)

    def test_no_forced_keyframe_count(self):
        self.assertEqual(store.validate(self.plan)[0], [])
        self.plan["segments"][0]["frames"]["keys"] = [
            {"at_seconds": t, "reason": "动作节点", "prompt": f"第{t}秒的完整可见状态", "reference_ids": ["P01"]} for t in (1, 3)
        ]
        self.assertEqual(store.validate(self.plan)[0], [])

    def test_invalid_reference_and_time_rejected(self):
        self.plan["segments"][0]["frames"]["keys"] = [{"at_seconds": 8, "reason": "测试", "prompt": "状态", "reference_ids": ["MISSING"]}]
        errors, _ = store.validate(self.plan)
        self.assertTrue(any("times" in e for e in errors))
        self.assertTrue(any("reference_ids" in e for e in errors))

    def test_append_and_locked_protection(self):
        first = self.save()
        original = (Path(first["path"]) / "project.json").read_bytes()
        self.plan["title"] = "标题更新"
        second = self.save()
        self.assertEqual(second["version"], "v0002")
        self.assertEqual((Path(first["path"]) / "project.json").read_bytes(), original)
        self.plan["segments"][0]["frames"]["last"]["prompt"] = "未经允许改变尾帧。"
        with self.assertRaisesRegex(ValueError, "Locked"):
            self.save()
        third = self.save(unlock=["C01"])
        self.assertEqual(third["version"], "v0003")
        audit = store.read_json(Path(third["path"]) / "change.json")
        self.assertEqual(audit["explicitly_unlocked"], ["C01"])
        self.assertFalse(audit["synced_to_github"])

    def test_removing_completed_segment_is_protected(self):
        old = fixture()
        old["segments"][0]["status"] = "complete"
        new = copy.deepcopy(old)
        new["segments"] = []
        self.assertEqual(store.locked_changes(old, new), ["C01"])

    def test_document_must_include_all_prompts(self):
        self.write()
        self.md.write_text("仅一个摘要", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "omits"):
            store.save(self.p, self.root / "archive", self.md, self.pdf, "test")

    def test_no_video_collection_or_path_escape(self):
        video = self.root / "input.mp4"
        video.write_bytes(b"video")
        with self.assertRaisesRegex(ValueError, "image"):
            self.save(references=[video])
        for unsafe in ("../escape", "C:/escape", "CON", "nul", "a/b"):
            self.plan["project_id"] = unsafe
            self.assertTrue(store.validate(self.plan)[0])

    def test_real_boundary_warning_and_allowed_cut(self):
        second = copy.deepcopy(self.plan["segments"][0])
        second["id"] = "C02"
        second["start_state"] = {"cup": "在空中"}
        self.plan["segments"][0]["transition_out"] = {"type": "continuous", "next_segment": "C02", "notes": "接续"}
        self.plan["segments"].append(second)
        self.assertTrue(any("states differ" in w for w in store.validate(self.plan)[1]))
        self.plan["segments"][0]["transition_out"]["type"] = "cut"
        self.assertEqual(store.validate(self.plan), ([], []))

    def test_workflows_save_without_frame_images(self):
        for workflow in ("multi_reference", "video_edit", "performance_driven", "footage_edit"):
            with self.subTest(workflow=workflow):
                self.plan = workflow_fixture(workflow)
                self.plan["project_id"] = workflow.replace("_", "-")
                self.assertEqual(store.validate(self.plan), ([], []))
                saved = Path(self.save()["path"])
                restored = store.read_json(saved / "project.json")
                self.assertNotIn("frames", restored["segments"][0])
                self.assertEqual(restored["segments"][0], self.plan["segments"][0])
                self.assertEqual(restored["included_references"], [])
                self.assertFalse((saved / "media").exists())

    def test_legacy_schemas_still_validate_and_save_unchanged(self):
        for version in ("1.0", "1.1"):
            for explicit_workflow in (False, True):
                with self.subTest(version=version, explicit_workflow=explicit_workflow):
                    self.plan = fixture()
                    self.plan["schema_version"] = version
                    self.plan["project_id"] = "legacy-" + version.replace(".", "-") + str(int(explicit_workflow))
                    if explicit_workflow:
                        self.plan["segments"][0]["workflow"] = "frame_based"
                    saved = self.save()
                    restored = store.read_json(Path(saved["path"]) / "project.json")
                    self.assertEqual(restored["schema_version"], version)
                    self.assertEqual(restored["segments"], self.plan["segments"])
                    del self.plan["segments"][0]["frames"]["last"]
                    self.assertTrue(any("last" in e for e in store.validate(self.plan)[0]))

    def test_modern_frame_workflow_only_checks_requested_frames(self):
        frame = fixture()["segments"][0]["frames"]["first"]
        for frames in ({"first": frame}, {"last": frame},
                       {"keys": [{**frame, "at_seconds": 2, "reason": "承重节点"}]}):
            with self.subTest(frames=frames):
                self.plan = workflow_fixture("frame_based")
                self.plan["assets"] = fixture()["assets"]
                self.plan["segments"][0]["input_assets"] = [{"asset_id": "P01", "role": "杯体身份"}]
                self.plan["segments"][0]["frames"] = frames
                self.assertEqual(store.validate(self.plan), ([], []))
                self.write()
                store.check_document(self.plan, self.md)
        self.plan["segments"][0]["frames"] = {"last": {"prompt": "", "reference_ids": []}}
        self.assertTrue(any("last" in e for e in store.validate(self.plan)[0]))

    def test_modern_inputs_and_execution_are_required_and_validated(self):
        mutations = (
            ("execution_prompt", "", "execution_prompt"),
            ("workflow", "", "workflow"),
            ("input_assets", [{"asset_id": "MISSING", "role": "动作"}], "input_assets"),
            ("input_assets", [{"asset_id": "V01", "role": ""}], "input_assets"),
            ("input_assets", None, "input_assets"),
            ("frames", [], "frames"),
        )
        for field, value, error in mutations:
            with self.subTest(field=field, value=value):
                plan = workflow_fixture()
                plan["segments"][0][field] = value
                self.assertTrue(any(error in e for e in store.validate(plan)[0]))

    def test_modern_document_requires_execution_and_optional_frame_prompts(self):
        self.plan = workflow_fixture()
        self.write()
        self.md.write_text("没有执行全文的摘要", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "omits"):
            store.save(self.p, self.root / "archive", self.md, self.pdf, "test")
        self.plan["segments"][0]["frames"] = {"last": {"prompt": "按需制作的独立目标图全文。", "reference_ids": []}}
        self.write()
        self.md.write_text(self.plan["segments"][0]["execution_prompt"], encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "omits"):
            store.save(self.p, self.root / "archive", self.md, self.pdf, "test")

    def test_modern_locks_protect_workflow_inputs_prompt_and_status(self):
        self.plan = workflow_fixture()
        self.save()
        baseline = copy.deepcopy(self.plan)
        changes = {"workflow": "footage_edit", "input_assets": [],
                   "execution_prompt": "改变动作方向。", "status": "draft"}
        for field, value in changes.items():
            with self.subTest(field=field):
                self.plan = copy.deepcopy(baseline)
                self.plan["segments"][0][field] = value
                with self.assertRaisesRegex(ValueError, "Locked"):
                    self.save()
        self.plan = copy.deepcopy(baseline)
        self.plan["segments"][0]["execution_prompt"] = "用户授权的新剪辑方案。"
        saved = self.save(unlock=["C01"])
        self.assertEqual(store.read_json(Path(saved["path"]) / "change.json")["explicitly_unlocked"], ["C01"])

    def test_schema_upgrade_preserves_legacy_locked_segments(self):
        second = copy.deepcopy(self.plan["segments"][0])
        second.update({"id": "C02", "status": "draft"})
        self.plan["segments"][0]["transition_out"] = {"type": "cut", "next_segment": "C02", "notes": "切到第二段"}
        self.plan["segments"].append(second)
        self.save()
        locked_original = copy.deepcopy(self.plan["segments"][0])
        modern_second = workflow_fixture()["segments"][0]
        modern_second.update({"id": "C02", "status": "draft"})
        self.plan["schema_version"] = "1.2"
        self.plan["assets"] += workflow_fixture()["assets"]
        self.plan["segments"][1] = modern_second
        saved = self.save()
        restored = store.read_json(Path(saved["path"]) / "project.json")
        self.assertEqual(restored["segments"][0], locked_original)
        self.assertNotIn("frames", restored["segments"][1])
        self.plan["segments"][0]["workflow"] = "frame_based"
        self.plan["segments"][0]["execution_prompt"] = self.plan["segments"][0]["video_prompt"]
        self.plan["segments"][0]["input_assets"] = []
        with self.assertRaisesRegex(ValueError, "Locked"):
            self.save()

    def test_schema_upgrade_keeps_explicit_legacy_frame_workflow(self):
        self.plan["schema_version"] = "1.1"
        self.plan["segments"][0]["workflow"] = "frame_based"
        self.save()
        original = copy.deepcopy(self.plan["segments"])
        self.plan["schema_version"] = "1.2"
        saved = self.save()
        restored = store.read_json(Path(saved["path"]) / "project.json")
        self.assertEqual(restored["segments"], original)
        self.assertNotIn("execution_prompt", restored["segments"][0])


if __name__ == "__main__":
    unittest.main()
