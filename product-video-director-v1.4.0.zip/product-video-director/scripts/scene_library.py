#!/usr/bin/env python3
"""Offline scene-library lookup and append-only imports. Python standard library only."""
from __future__ import annotations

import argparse
import contextlib
import copy
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from datetime import datetime, timezone

DEFAULT_LIBRARY = Path(__file__).resolve().parents[1] / "library"
TAG_FIELDS = ("setting", "styles", "moods", "space", "elements", "shot_roles")
CLAIM_TERMS = ("防水", "耐热", "耐寒", "防沙", "防尘", "认证", "功效", "疗效", "成分", "产地", "防晒", "抗菌", "降噪")
SCENE_TEXT = ("id", "title", "base_prompt")
SCENE_LISTS = ("details", "nouns", "adjectives", "verbs", "checks")
VARIANT_TEXT = ("id", "style", "visual_intent", "image_prompt", "video_prompt", "end_state", "adaptation")


class LibraryError(ValueError):
    pass


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def canonical_id(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"S[0-9]{2,6}", value):
        raise LibraryError("场景 ID 必须为 S01、S60、S100 等形式。")
    if int(value[1:]) < 1 or value != f"S{int(value[1:]):02d}":
        raise LibraryError("场景 ID 必须使用唯一的规范写法，不允许 S001 或 S00。")
    return value


def safe_path(root: Path, *parts: str) -> Path:
    root = root.resolve()
    path = root.joinpath(*parts)
    resolved = path.resolve()
    if not resolved.is_relative_to(root):
        raise LibraryError("路径必须位于指定场景库内。")
    return path


def validate_scene(scene: dict) -> None:
    if not isinstance(scene, dict):
        raise LibraryError("每个场景必须是 JSON 对象。")
    canonical_id(scene.get("id"))
    for key in SCENE_TEXT:
        if not isinstance(scene.get(key), str) or not scene[key].strip():
            raise LibraryError(f"场景缺少非空文本字段：{key}")
    for key in SCENE_LISTS:
        values = scene.get(key)
        if not isinstance(values, list) or not values or any(not isinstance(v, str) or not v.strip() for v in values):
            raise LibraryError(f"{key} 必须是非空字符串列表。")
    variants = scene.get("variants")
    if not isinstance(variants, list) or not variants:
        raise LibraryError("variants 至少需要一个完整方案；不强制三个。")
    seen = set()
    for variant in variants:
        if not isinstance(variant, dict):
            raise LibraryError("风格方案必须是对象。")
        for key in VARIANT_TEXT:
            if not isinstance(variant.get(key), str) or not variant[key].strip():
                raise LibraryError(f"风格方案缺少非空文本字段：{key}")
        if not re.fullmatch(re.escape(scene["id"]) + r"-[A-Za-z0-9][A-Za-z0-9_-]*", variant["id"]):
            raise LibraryError("风格方案 ID 必须以其场景 ID 开头，例如 S61-A。")
        if variant["id"] in seen:
            raise LibraryError("同一场景内风格方案 ID 不能重复。")
        seen.add(variant["id"])


def validate_tags(tags: dict) -> dict:
    if not isinstance(tags, dict) or set(tags) - set(TAG_FIELDS):
        raise LibraryError("tags 只能包含 setting/styles/moods/space/elements/shot_roles。")
    result = {}
    for key in TAG_FIELDS:
        values = tags.get(key, [])
        if not isinstance(values, list) or any(not isinstance(v, str) or not v.strip() for v in values):
            raise LibraryError(f"tags.{key} 必须是字符串列表。")
        if any(term in value for value in values for term in CLAIM_TERMS):
            raise LibraryError("场景检索标签不能包含产品性能、成分或认证词；请把事实及限制留在项目资料或场景正文。")
        # Tags describe visible positive scene features, never infer product performance.
        result[key] = list(dict.fromkeys(v.strip() for v in values))
    return result


def default_tags(scene: dict) -> dict:
    # Deliberately exclude base_prompt, checks, adaptation and other prose with negation.
    return validate_tags({
        "setting": [scene["title"]],
        "styles": [v["style"] for v in scene["variants"]],
        "elements": list(scene["nouns"]),
        "moods": [], "space": [], "shot_roles": [],
    })


def load_index(root: Path) -> dict:
    index = read_json(safe_path(root, "index.json"))
    if index.get("schema_version") != 1 or not isinstance(index.get("scenes"), list):
        raise LibraryError("不支持的场景库索引格式。")
    seen = set()
    for entry in index["scenes"]:
        canonical_id(entry.get("id"))
        if entry["id"] in seen:
            raise LibraryError("索引包含重复场景 ID。")
        seen.add(entry["id"])
        for version in entry["versions"]:
            safe_path(root, version["path"])
    return index


def find_entry(index: dict, scene_id: str) -> dict:
    canonical_id(scene_id)
    for entry in index["scenes"]:
        if entry["id"] == scene_id:
            return entry
    raise LibraryError(f"未找到场景 {scene_id}。")


def read_record(root: Path, entry: dict, version: str | None = None) -> dict:
    version = version or entry["latest_version"]
    if not re.fullmatch(r"v[0-9]{3,6}", version):
        raise LibraryError("版本必须写成 v001 等形式。")
    matches = [v for v in entry["versions"] if v["version"] == version]
    if len(matches) != 1:
        raise LibraryError(f"{entry['id']} 不存在版本 {version}。")
    return read_json(safe_path(root, matches[0]["path"]))


def list_scenes(root: Path, limit: int = 100) -> dict:
    index = load_index(root)
    return {"total": len(index["scenes"]), "scenes": [
        {**{k: e[k] for k in ("id", "title", "latest_version", "variant_count")},
         "styles": e["tags"]["styles"], "version_count": len(e["versions"])}
        for e in index["scenes"][:limit]
    ]}


def search_scenes(root: Path, query: str, limit: int = 6, match: str = "any") -> dict:
    terms = list(dict.fromkeys(t.casefold() for t in re.split(r"[\s,，、;；+]+", query.strip()) if t))
    if not terms:
        raise LibraryError("搜索词不能为空。建议输入 2–5 个以空格分开的场景或视觉词。")
    index = load_index(root)
    results = []
    weights = {"title": 8, "setting": 6, "styles": 4, "moods": 3, "space": 2, "elements": 2, "shot_roles": 2}
    for entry in index["scenes"]:
        fields = {"title": [entry["title"]], **entry["tags"]}
        evidence = []
        score = 0
        matched_terms = set()
        for term in terms:
            for field, values in fields.items():
                hits = [value for value in values if term in value.casefold()]
                if hits:
                    evidence.append({"term": term, "field": field, "values": hits})
                    matched_terms.add(term)
                    score += weights[field]
        if score and (match == "any" or len(matched_terms) == len(terms)):
            results.append({"id": entry["id"], "title": entry["title"], "version": entry["latest_version"],
                            "score": score, "matched_terms": sorted(matched_terms), "evidence": evidence,
                            "variant_styles": entry["tags"]["styles"]})
    results.sort(key=lambda e: (-e["score"], int(e["id"][1:])))
    return {"query": query, "terms": terms, "match": match, "total_matches": len(results),
            "note": "分数仅为可解释的视觉词匹配，不是产品适配概率或性能证明。",
            "results": results[:limit]}


def show_scene(root: Path, scene_id: str, version: str | None = None, variant_id: str | None = None) -> dict:
    entry = find_entry(load_index(root), scene_id)
    record = read_record(root, entry, version)
    if variant_id:
        variants = [v for v in record["scene"]["variants"] if v["id"] == variant_id]
        if len(variants) != 1:
            raise LibraryError("指定版本中没有该风格方案。")
        record = copy.deepcopy(record)
        record["scene"]["variants"] = variants
        record["selected_variant"] = variant_id
    return record


def _atomic_json(path: Path, data: dict):
    name = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", suffix=".tmp", prefix="index-", dir=path.parent, delete=False) as stream:
            name = Path(stream.name)
            json.dump(data, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if name and name.exists():
            name.unlink()


def import_scenes(root: Path, payload, source: str, source_kind: str = "user-authored", revision_kind: str = "user_revision") -> dict:
    if not source.strip():
        raise LibraryError("必须记录非空来源说明。")
    if source_kind not in ("user-authored", "user-adapted", "external-reference"):
        raise LibraryError("不支持的来源类别。")
    if revision_kind not in ("user_revision", "user_variant"):
        raise LibraryError("修改类别必须为 user_revision 或 user_variant。")
    items = payload if isinstance(payload, list) else [payload]
    if not items:
        raise LibraryError("导入列表为空。")
    prepared = []
    seen = set()
    for item in items:
        if not isinstance(item, dict):
            raise LibraryError("导入条目必须是场景或含 scene/tags 的对象。")
        scene = item.get("scene", item)
        validate_scene(scene)
        if scene["id"] in seen:
            raise LibraryError("同一批导入不能重复提交同一个场景 ID。")
        seen.add(scene["id"])
        tags = validate_tags(item["tags"]) if "scene" in item and "tags" in item else default_tags(scene)
        prepared.append((copy.deepcopy(scene), tags))

    root = root.resolve()
    lock = safe_path(root, ".import.lock")
    written = []
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as exc:
        raise LibraryError("场景库正被其他进程导入。确认其完成后再重试；不要覆盖正在使用的版本。") from exc
    try:
        os.close(descriptor)
        index = load_index(root)
        now = datetime.now(timezone.utc).isoformat()
        receipt = []
        for scene, tags in prepared:
            scene_id = scene["id"]
            entry = next((e for e in index["scenes"] if e["id"] == scene_id), None)
            parent_version = entry["latest_version"] if entry else None
            revision = max((int(v["version"][1:]) for v in entry["versions"]), default=0) + 1 if entry else 1
            version = f"v{revision:03d}"
            relative = f"scenes/{scene_id}/{version}.json"
            path = safe_path(root, relative)
            # This fails closed if a stale/unindexed version already exists.
            if path.exists():
                raise LibraryError(f"版本路径已存在，拒绝覆盖：{relative}")
            kind = revision_kind if entry else "user_created"
            record = {"schema_version": 1, "scene_id": scene_id, "version": version, "kind": kind,
                      "parent_version": parent_version, "created_at": now,
                      "provenance": {"source_kind": source_kind, "source": source}, "tags": tags, "scene": scene,
                      "usage_note": "end_state 是结束状态摘要；先选择适用的生成工作流，再按需准备参考素材和独立执行提示词，不默认制作首尾帧。本记录不是跨段故事。"}
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x", encoding="utf-8", newline="\n") as stream:
                json.dump(record, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
            written.append(path)
            version_entry = {"version": version, "path": relative, "kind": kind}
            if entry:
                entry.update(title=scene["title"], latest_version=version, tags=tags, variant_count=len(scene["variants"]))
                entry["versions"].append(version_entry)
            else:
                index["scenes"].append({"id": scene_id, "title": scene["title"], "latest_version": version,
                                        "variant_count": len(scene["variants"]), "tags": tags, "versions": [version_entry]})
            receipt.append({"id": scene_id, "version": version, "parent_version": parent_version, "path": relative})
        index["scenes"].sort(key=lambda e: int(e["id"][1:]))
        index["updated_at"] = now
        _atomic_json(safe_path(root, "index.json"), index)
        return {"imported": receipt, "note": "已追加新版本；此前版本及原始资料未覆盖。"}
    except Exception:
        for path in written:
            with contextlib.suppress(OSError):
                path.unlink()
        raise
    finally:
        with contextlib.suppress(OSError):
            lock.unlink()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", type=Path, default=DEFAULT_LIBRARY)
    sub = parser.add_subparsers(dest="command", required=True)
    listing = sub.add_parser("list", help="列出场景、风格与版本")
    listing.add_argument("--limit", type=int, default=100)
    search = sub.add_parser("search", help="正面视觉词搜索，不代表产品性能")
    search.add_argument("query")
    search.add_argument("--limit", type=int, default=6)
    search.add_argument("--match", choices=("any", "all"), default="any")
    show = sub.add_parser("show", help="读取一个完整场景或一个风格方案")
    show.add_argument("scene_id")
    show.add_argument("--version")
    show.add_argument("--variant")
    importer = sub.add_parser("import", help="从 JSON 追加一个或一批场景新版本")
    importer.add_argument("input", type=Path)
    importer.add_argument("--source", required=True)
    importer.add_argument("--source-kind", choices=("user-authored", "user-adapted", "external-reference"), default="user-authored")
    importer.add_argument("--revision-kind", choices=("user_revision", "user_variant"), default="user_revision", help="已有场景的普通修订或用户风格变体；新 ID 始终标为 user_created")
    args = parser.parse_args(argv)
    try:
        if hasattr(args, "limit") and args.limit < 1:
            raise LibraryError("limit 必须为正整数。")
        if args.command == "list":
            result = list_scenes(args.library, args.limit)
        elif args.command == "search":
            result = search_scenes(args.library, args.query, args.limit, args.match)
        elif args.command == "show":
            result = show_scene(args.library, args.scene_id, args.version, args.variant)
        else:
            result = import_scenes(args.library, read_json(args.input), args.source, args.source_kind, args.revision_kind)
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (LibraryError, OSError, ValueError, KeyError, TypeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
