# 正式交付、版本与项目恢复

## 正式方案如何交付

聊天先给概览与最值得关注的制作选择，再给完整 Markdown/文本与 PDF 链接。完整视频文件包括：产品事实/待确认项、参考资产角色、选定故事及场景来源、分段总览、每段全部首关键尾图像提示词与动态/衔接、简化方案、剪辑声音建议。文件里保留全文，不用聊天里的“展开后查看”或摘要代替。

单镜头正式方案可只含该段相关内容。方向探索和简短问答不用强制导出。局部返修交付新的完整版本，另列修改了什么以及哪些前后段保持不变。

生成 PDF 时可用当前环境的 PDF 能力，也可运行 `scripts/export_pdf.py`。读取脚本帮助确认参数。需要 ReportLab 与可嵌入中文字体；缺依赖时使用环境已有文档工具，不自动安装未知程序。打开/渲染最终 PDF，检查中文、分页、长提示词和链接；结构检查不代表排版或语义正确。

## 两个存放位置

- 技能仓库：本技能、60 场景原库、通用新增场景、参考规则、模板、测试和第三方声明。
- 个人项目仓库/本地档案：真实产品资料、必要参考图、故事与逐帧方案、PDF、版本、变更说明、素材文件名/路径索引。真实项目不要放进技能仓库。

不默认上传全部生成图、原始视频、生成片段或下载目录。只有确实用于本项目且用户授权的必要参考图才随档案保存；其余素材记路径或文件名。同步前只列本次要上传的文件，不扫描无关个人目录。

当前使用者约定：正式版本先本地保存；用户明确说“同步/保存到 GitHub”时再上传个人项目。没有可用连接或权限时保留本地成果并说明具体未完成项。不要创建自动同步任务。一次同步授权不代表以后每次都能上传。

## 可选结构化项目记录

为了可靠保护锁定片段，可以为正式方案同时保存 `project.json`。它与 Markdown 表达同一方案，不是交给生图工具的提示词。脚本不要求用户手填，由代理从已确定方案构建。

```json
{
  "schema_version": "1.0",
  "project_id": "ceramic-cup-demo",
  "title": "陶瓷杯产品短片",
  "brief": {
    "product_facts": ["演示设定：白色无字陶瓷杯，单把手"],
    "style": "自然晨光",
    "purpose": "产品外观介绍",
    "aspect_ratio": "16:9"
  },
  "assets": [
    {"id": "P01", "role": "产品身份", "path": "refs/cup.png", "notes": "保持杯体轮廓与把手，不推断不可见底部"}
  ],
  "story": {"selected_direction": "晨光揭示", "summary": "从轮廓到产品全貌"},
  "segments": [
    {
      "id": "C01",
      "status": "draft",
      "purpose": "揭示杯体轮廓和釉面反光",
      "duration_seconds": 5,
      "scene": {"name": "晨光桌面", "source_kind": "new"},
      "start_state": {"cup": "桌面中央，把手朝右", "light": "左侧窄光"},
      "end_state": {"cup": "桌面中央，把手朝右", "light": "左侧柔光覆盖杯体"},
      "frames": {
        "first": {"prompt": "这里填写完整独立首帧提示词，实际交付不能保留占位说明。", "reference_ids": ["P01"]},
        "keys": [],
        "last": {"prompt": "这里填写完整独立尾帧提示词，包含改变后的灯光状态。", "reference_ids": ["P01"]}
      },
      "video_prompt": "这里填写完整动态提示词及按时间发生的变化。",
      "transition_out": {"type": "end", "next_segment": null, "notes": "停留后淡出；文字后期叠加"},
      "complex_shot": false,
      "editing_notes": "可选安静环境声；无未经确认的功能文案"
    }
  ]
}
```

上例只演示字段，不能作为实际制作交付。`frames.keys` 可以为 `[]`；需要关键帧时每张增加 `id`、`at_seconds`、`reason`、完整 `prompt` 与 `reference_ids`。关键时间按顺序落在片段内部。`status` 为 `draft`、`locked` 或 `complete`，后两种都保护内容。

`scene.source_kind` 为 `library` / `adapted` / `new`；前两种写 `scene_id`，有具体风格版本时加 `variant_id`。场景编号 S01 与片段编号 C01 分开。`transition_out.type` 为 `continuous` / `match_cut` / `cut` / `bridge` / `end`，非最终段的 `next_segment` 指向实际下一段。用户要求固定总长时在 `brief.fixed_duration_seconds` 填数值，否则不强加总长。

每条帧的 `reference_ids` 引用已登记素材，不能用一个不存在的“参考图”控制产品。复杂镜头标记 `complex_shot: true` 并填写 `simplified_alternative`。起止状态对象按故事需要记录关键事实，不必每次套满人物字段。

## 保存与锁定保护

```text
python scripts/project_store.py validate project.json
python scripts/project_store.py save project.json --archive /chosen/private-archive --document plan.md --pdf plan.pdf --change "首个正式版本"
```

路径示例需要替换为实际可写目录；可执行 Python 名称由环境决定。保存产生 `项目ID/versions/v0001/`，后续追加 `v0002`，含结构化方案、完整 Markdown、PDF、变更摘要和文件校验值。不会联网或上传。

脚本核对逐帧/动态提示词在 Markdown 中完整存在，检查引用、时间和结构，拒绝改动或删除上一版本已锁定/完成片段。只有用户明确批准修改指定片段后，才可传 `--unlock C01`，该操作记录在变更说明。不要为绕过保存错误自动补这个参数。新版本完成后重新标记锁定状态。

`--reference /path/to/selected-image.png` 可追加必要图片，仅接受图片，不接受视频。显式参考列表不会从磁盘自动搜集。锁定片段依赖的产品事实/参考图若发生变化，即使片段文本相同，也需由代理检查实际影响，不能依赖脚本判定安全。

结构警告需要逐项审读，特别是连续边界起止状态不一致；脚本比较文字不能判断所有语义等价或视觉矛盾。PDF头检查也不是有效排版或内容验证，仍需单独渲染检查。

## 恢复旧项目

先读取实际最新版 `project.json`、`plan.md`、变更记录和资产索引，确认用户这次修改的目标。用户另有分支版本时以其明确选择为准。不要只靠对话记忆声称知道锁定状态，不把场景库模板版本当个人项目版本。需要同步时记录目标仓库、实际上传文件与返回提交；没有返回成功凭证不要称“已同步”。
