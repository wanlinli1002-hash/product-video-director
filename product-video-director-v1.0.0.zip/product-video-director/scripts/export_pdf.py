#!/usr/bin/env python3
"""Export a readable Chinese Markdown PDF locally; requires reportlab and CJK TTF/TTC.

No network calls. Existing output is protected unless --force is supplied.
Supported: headings, paragraphs, bullets, fenced text, links, simple tables,
and <!-- pagebreak -->. Tables become readable labeled records to avoid clipping.
"""
from __future__ import annotations

import argparse
from html import escape
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile


def font_candidates(explicit=None):
    if explicit:
        return [Path(explicit).expanduser()]
    configured = os.environ.get("PRODUCT_VIDEO_CJK_FONT")
    paths = [Path(configured).expanduser()] if configured else []
    windir = Path(os.environ.get("WINDIR", "C:/Windows"))
    paths.extend([
        windir / "Fonts/msyh.ttc", windir / "Fonts/simhei.ttf",
        Path("/System/Library/Fonts/STHeiti Light.ttc"),
        Path("/System/Library/Fonts/STHeiti Medium.ttc"),
        Path("/Library/Fonts/Arial Unicode.ttf"),
        Path("/usr/share/fonts/truetype/arphic/uming.ttc"),
        Path("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc"),
        Path("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"),
    ])
    return paths


def select_font(text, explicit=None, index=0):
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    # Markup stays in the file, so checking it too is conservative and harmless.
    required = {ord(c) for c in text if not c.isspace() and ord(c) >= 32}
    diagnostics = []
    for path in font_candidates(explicit):
        if not path.is_file():
            continue
        try:
            font = TTFont("ProductCJK", str(path), subfontIndex=index)
            missing = required - set(font.face.charToGlyph)
            if missing:
                sample = " ".join(f"U+{c:04X}" for c in sorted(missing)[:12])
                diagnostics.append(f"{path.name}: missing {sample}")
                continue
            pdfmetrics.registerFont(font)
            pdfmetrics.registerFontFamily("ProductCJK", normal="ProductCJK", bold="ProductCJK", italic="ProductCJK", boldItalic="ProductCJK")
            return "ProductCJK", str(path)
        except Exception as exc:
            diagnostics.append(f"{path.name}: {exc}")
    details = "; ".join(diagnostics)
    raise ValueError("No usable TrueType Chinese font covers this document. Supply --font PATH [--font-index N] or PRODUCT_VIDEO_CJK_FONT. " + details)


def inline(text):
    # Escape all input before introducing our own small set of trusted PDF tags.
    value = escape(text)
    value = re.sub(r"\[([^\]]+)\]\((https?://[^\s)]+)\)", lambda m: f'<link href="{m.group(2)}" color="#236F87">{m.group(1)}</link>', value)
    value = re.sub(r"`([^`]+)`", r'<font color="#23556B">\1</font>', value)
    value = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", value)
    return value


def parse_markdown(text, styles):
    from reportlab.platypus import Paragraph, Spacer, PageBreak
    story = []
    lines = text.splitlines()
    i = 0
    in_code = False
    table_header = None
    while i < len(lines):
        raw = lines[i]
        line = raw.strip()
        i += 1
        if line.startswith("```"):
            in_code = not in_code
            story.append(Spacer(1, 5))
            continue
        if in_code:
            # A paragraph per code line may wrap and split across pages safely.
            value = escape(raw).replace(" ", "&#160;") or "&#160;"
            story.append(Paragraph(value, styles["code"]))
            continue
        if line == "<!-- pagebreak -->":
            if story and not isinstance(story[-1], PageBreak):
                story.append(PageBreak())
            table_header = None
            continue
        if not line:
            continue
        if line.startswith("<!--"):
            continue
        heading = re.match(r"^(#{1,6})\s+(.+)$", line)
        if heading:
            depth = len(heading.group(1))
            key = "h1" if depth == 1 else "h2" if depth == 2 else "h3"
            story.append(Paragraph(inline(heading.group(2)), styles[key]))
            continue
        if line.startswith("|") and line.endswith("|"):
            cells = [c.strip() for c in line[1:-1].split("|")]
            if all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                continue
            if table_header is None and i < len(lines) and re.match(r"^\s*\|[\s:|\-]+\|\s*$", lines[i]):
                table_header = cells
                continue
            if table_header:
                for n, cell in enumerate(cells):
                    label = table_header[n] if n < len(table_header) else str(n + 1)
                    story.append(Paragraph(inline(f"**{label}：** {cell}"), styles["body"]))
                story.append(Spacer(1, 5))
            else:
                story.append(Paragraph(inline(" / ".join(cells)), styles["body"]))
            continue
        table_header = None
        bullet = re.match(r"^[-*+]\s+(.+)$", line)
        if bullet:
            story.append(Paragraph(inline(bullet.group(1)), styles["bullet"], bulletText="-"))
            continue
        if re.fullmatch(r"[-*_]{3,}", line):
            story.append(Spacer(1, 10))
            continue
        # Respect explicit newlines without flattening distinct prompt paragraphs.
        story.append(Paragraph(inline(line), styles["body"]))
    if in_code:
        raise ValueError("Unclosed fenced code block in Markdown")
    if not story:
        raise ValueError("The Markdown document has no visible content")
    return story


def export_pdf(source, output, title=None, font=None, font_index=0, force=False):
    try:
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_LEFT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.platypus import SimpleDocTemplate
    except ImportError as exc:
        raise RuntimeError("reportlab is required. Install it in the chosen Python environment before exporting.") from exc
    source = Path(source).resolve()
    output = Path(output).resolve()
    if source == output:
        raise ValueError("Input and output must be different files")
    if output.suffix.lower() != ".pdf":
        raise ValueError("Output filename must end in .pdf")
    if output.exists() and not force:
        raise FileExistsError("Output already exists; choose a new version or pass --force explicitly")
    text = source.read_text(encoding="utf-8-sig")
    title = title or source.stem
    font_name, font_path = select_font(text + title + "产品视频导演 使用指南 0123456789", font, font_index)
    common = dict(fontName=font_name, textColor=colors.HexColor("#243745"), wordWrap="CJK", splitLongWords=1, alignment=TA_LEFT)
    styles = {
        "body": ParagraphStyle("body", fontSize=10.5, leading=17, spaceAfter=9, **common),
        "bullet": ParagraphStyle("bullet", fontSize=10.2, leading=16.8, spaceAfter=8, leftIndent=12, firstLineIndent=0, bulletIndent=0, **common),
        "h1": ParagraphStyle("h1", fontSize=23, leading=31, spaceAfter=20, keepWithNext=True, **common),
        "h2": ParagraphStyle("h2", fontSize=14, leading=21, spaceBefore=9, spaceAfter=10, keepWithNext=True, **common),
        "h3": ParagraphStyle("h3", fontSize=12, leading=19, spaceBefore=8, spaceAfter=8, keepWithNext=True, **common),
        "code": ParagraphStyle("code", fontSize=9.5, leading=16, spaceAfter=1, leftIndent=10, rightIndent=10, backColor=colors.HexColor("#F0F5F7"), borderPadding=5, **common),
    }
    story = parse_markdown(text, styles)
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".pdf-export-", suffix=".pdf", dir=output.parent)
    os.close(fd)
    temp = Path(temp_name)
    try:
        def decorate(canvas, doc):
            canvas.saveState()
            width, height = A4
            canvas.setStrokeColor(colors.HexColor("#CBDDE5"))
            canvas.setLineWidth(0.6)
            canvas.line(47, height - 47, width - 47, height - 47)
            canvas.setFont(font_name, 8)
            canvas.setFillColor(colors.HexColor("#587181"))
            canvas.drawString(47, height - 35, "PRODUCT VIDEO DIRECTOR")
            canvas.drawRightString(width - 47, 29, str(doc.page))
            canvas.drawString(47, 29, title[:45])
            canvas.restoreState()
        doc = SimpleDocTemplate(str(temp), pagesize=A4, rightMargin=47, leftMargin=47, topMargin=66, bottomMargin=52, title=title, author="Product Video Director", pageCompression=1)
        doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
        if force:
            os.replace(temp, output)
        else:
            # Exclusive creation protects against another writer appearing mid-export.
            created = False
            try:
                with output.open("xb") as dest, temp.open("rb") as src:
                    created = True
                    shutil.copyfileobj(src, dest)
            except Exception:
                if created:
                    output.unlink(missing_ok=True)
                raise
        return {"output": str(output), "font": font_path, "bytes": output.stat().st_size}
    finally:
        temp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--title")
    parser.add_argument("--font")
    parser.add_argument("--font-index", type=int, default=0)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    try:
        result = export_pdf(args.input, args.output, args.title, args.font, args.font_index, args.force)
        print(result)
        return 0
    except Exception as exc:
        print(f"PDF export failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
