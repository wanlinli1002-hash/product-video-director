#!/usr/bin/env python3
"""Local, append-only formal plan storage. No network or generation calls."""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def safe_id(value):
    reserved = {"con", "prn", "aux", "nul", *[f"com{i}" for i in range(1, 10)], *[f"lpt{i}" for i in range(1, 10)]}
    return isinstance(value, str) and bool(re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,63}", value)) and value.lower() not in reserved


def text_ok(value):
    return isinstance(value, str) and bool(value.strip())


def validate(plan):
    """Structural checks only; warnings deliberately require semantic review."""
    errors, warnings = [], []
    if not isinstance(plan, dict):
        return ["Project must be an object"], []
    if plan.get("schema_version") != "1.0":
        errors.append("schema_version must be 1.0")
    if not safe_id(plan.get("project_id")):
        errors.append("project_id must be a safe lowercase identifier")
    if not text_ok(plan.get("title")):
        errors.append("title is required")
    if not isinstance(plan.get("brief"), dict) or not plan["brief"]:
        errors.append("brief must contain confirmed product facts and creative requirements")
    assets = plan.get("assets", [])
    if not isinstance(assets, list) or any(not isinstance(a, dict) for a in assets):
        return errors + ["assets must be a list of objects"], warnings
    asset_ids = [a.get("id") for a in assets]
    if any(not text_ok(a) for a in asset_ids) or len(set(asset_ids)) != len(asset_ids):
        errors.append("Asset IDs must be non-empty and unique")
    for asset in assets:
        if not text_ok(asset.get("role")):
            errors.append(f"Asset {asset.get('id')} needs an explicit role")
    segments = plan.get("segments")
    if not isinstance(segments, list) or not segments or any(not isinstance(s, dict) for s in segments):
        return errors + ["segments must contain at least one segment object"], warnings
    ids = [s.get("id") for s in segments]
    if any(not text_ok(i) for i in ids) or len(set(ids)) != len(ids):
        errors.append("Segment IDs must be non-empty and unique")
    total = 0.0
    for index, seg in enumerate(segments):
        label = str(seg.get("id", index + 1))
        if seg.get("status") not in {"draft", "locked", "complete"}:
            errors.append(f"{label}: status must be draft, locked, or complete")
        duration = seg.get("duration_seconds")
        valid_duration = isinstance(duration, (int, float)) and not isinstance(duration, bool) and math.isfinite(duration) and duration > 0
        if not valid_duration:
            errors.append(f"{label}: duration_seconds must be positive and finite")
        else:
            total += duration
        for field in ("purpose", "video_prompt"):
            if not text_ok(seg.get(field)):
                errors.append(f"{label}: missing {field}")
        for field in ("start_state", "end_state"):
            if not isinstance(seg.get(field), dict) or not seg[field]:
                errors.append(f"{label}: {field} must be a non-empty state object")
        scene = seg.get("scene", {})
        if not isinstance(scene, dict) or scene.get("source_kind") not in {"library", "adapted", "new"}:
            errors.append(f"{label}: scene.source_kind must be library, adapted, or new")
        elif scene["source_kind"] in {"library", "adapted"} and not text_ok(scene.get("scene_id")):
            errors.append(f"{label}: library/adapted scene needs scene_id")
        frames = seg.get("frames", {})
        if not isinstance(frames, dict):
            frames = {}
        keys = frames.get("keys", [])
        if not isinstance(keys, list):
            errors.append(f"{label}: frames.keys must be a list, including [] when unnecessary")
            keys = []
        previous_time = 0
        for key in keys:
            if not isinstance(key, dict):
                errors.append(f"{label}: each key frame must be an object")
                continue
            t = key.get("at_seconds")
            if not isinstance(t, (float, int)) or isinstance(t, bool) or not math.isfinite(t) or not (t > previous_time and (not valid_duration or t < duration)):
                errors.append(f"{label}: key frames need strictly ordered times inside the clip")
            else:
                previous_time = t
            if not text_ok(key.get("reason")):
                errors.append(f"{label}: key frame needs its purpose/reason")
        for role, frame in [("first", frames.get("first")), *[(f"key-{i+1}", k) for i, k in enumerate(keys)], ("last", frames.get("last"))]:
            if not isinstance(frame, dict) or not text_ok(frame.get("prompt")):
                errors.append(f"{label}/{role}: full prompt is required")
                continue
            refs = frame.get("reference_ids")
            if not isinstance(refs, list) or any(r not in asset_ids for r in refs):
                errors.append(f"{label}/{role}: reference_ids must refer to declared assets (or be [])")
            if re.search(r"同上|其余同前|其余同上|same as (?:above|before)", frame["prompt"], re.I):
                warnings.append(f"{label}/{role}: check that this frame is independently usable")
        transition = seg.get("transition_out", {})
        if not isinstance(transition, dict) or transition.get("type") not in {"continuous", "match_cut", "cut", "bridge", "end"}:
            errors.append(f"{label}: specify transition_out.type")
            continue
        last = index == len(segments) - 1
        if last:
            if transition["type"] != "end" or transition.get("next_segment") not in (None, ""):
                errors.append(f"{label}: final segment must end with no next_segment")
        elif transition["type"] == "end" or transition.get("next_segment") != ids[index + 1]:
            errors.append(f"{label}: transition must point to the actual next segment")
        if not text_ok(transition.get("notes")):
            errors.append(f"{label}: transition notes are required")
        if not last and transition["type"] == "continuous" and seg.get("end_state") != segments[index + 1].get("start_state"):
            warnings.append(f"{label}: continuous boundary states differ; review meaning before delivery")
        if seg.get("complex_shot") and not text_ok(seg.get("simplified_alternative")):
            errors.append(f"{label}: complex shot needs a simplified alternative")
    target = plan.get("brief", {}).get("fixed_duration_seconds") if isinstance(plan.get("brief"), dict) else None
    if target is not None and (not isinstance(target, (int, float)) or isinstance(target, bool) or not math.isfinite(target) or abs(total - target) > 0.05):
        errors.append("Segment durations do not match brief.fixed_duration_seconds")
    return errors, warnings


def locked_changes(old, new, unlock=()):
    current = {s["id"]: s for s in new["segments"]}
    allowed = set(unlock)
    unknown = allowed - {s["id"] for s in old["segments"]}
    if unknown:
        raise ValueError(f"Unknown unlock segment IDs: {sorted(unknown)}")
    violations = []
    for previous in old["segments"]:
        if previous.get("status") in {"locked", "complete"} and previous["id"] not in allowed:
            if previous != current.get(previous["id"]):
                violations.append(previous["id"])
    return violations


def normalize(value):
    return re.sub(r"\s+", "", value)


def check_document(plan, document):
    body = normalize(Path(document).read_text(encoding="utf-8-sig"))
    for s in plan["segments"]:
        frames = s["frames"]
        prompts = [frames["first"]["prompt"], *[k["prompt"] for k in frames.get("keys", [])], frames["last"]["prompt"], s["video_prompt"]]
        if any(normalize(p) not in body for p in prompts):
            raise ValueError(f"Editable document omits or differs from a prompt in {s['id']}")


def save(plan_path, archive, document, pdf, change, unlock=(), references=()):
    plan = read_json(plan_path)
    errors, warnings = validate(plan)
    if errors:
        raise ValueError("; ".join(errors))
    check_document(plan, document)
    if not Path(pdf).read_bytes().startswith(b"%PDF-"):
        raise ValueError("PDF file is missing a valid PDF header")
    if not text_ok(change):
        raise ValueError("A change summary is required")
    for ref in references:
        if Path(ref).suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp", ".gif"} or not Path(ref).is_file():
            raise ValueError("Explicit references must be existing image files; videos stay indexed, not auto-uploaded")
    root = Path(archive).resolve()
    project = root / plan["project_id"]
    project.mkdir(parents=True, exist_ok=True)
    if project.resolve().parent != root:
        raise ValueError("Project directory escapes archive root")
    lock = project / ".save.lock"
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.close(fd)
    temp = None
    try:
        versions = project / "versions"
        versions.mkdir(exist_ok=True)
        existing = sorted(p for p in versions.iterdir() if p.is_dir() and re.fullmatch(r"v\d{4,}", p.name))
        if existing:
            latest = max(existing, key=lambda p: int(p.name[1:]))
            old = read_json(latest / "project.json")
            changed = locked_changes(old, plan, unlock)
            if changed:
                raise ValueError(f"Locked/complete segments changed or removed: {changed}. Obtain explicit user unlock before using --unlock.")
            number = int(latest.name[1:]) + 1
        else:
            if unlock:
                raise ValueError("No prior version exists to unlock")
            number = 1
        target = versions / f"v{number:04d}"
        if target.exists():
            raise FileExistsError(target)
        temp = Path(tempfile.mkdtemp(prefix=".pending-", dir=project))
        saved = deepcopy(plan)
        saved["version"] = target.name
        saved["saved_at"] = datetime.now(timezone.utc).isoformat()
        saved["included_references"] = []
        for i, ref in enumerate(references, 1):
            source = Path(ref)
            rel = f"references/ref-{i:03d}{source.suffix.lower()}"
            (temp / "references").mkdir(exist_ok=True)
            shutil.copyfile(source, temp / rel)
            saved["included_references"].append({"original_path": str(source.resolve()), "stored_path": rel})
        (temp / "project.json").write_text(json.dumps(saved, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        shutil.copyfile(document, temp / "plan.md")
        shutil.copyfile(pdf, temp / "plan.pdf")
        (temp / "change.json").write_text(json.dumps({"summary": change, "explicitly_unlocked": list(unlock), "structural_warnings": warnings, "synced_to_github": False}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        hashes = {p.relative_to(temp).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(temp.rglob("*")) if p.is_file()}
        (temp / "manifest.json").write_text(json.dumps({"sha256": hashes}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temp.rename(target)
        temp = None
        return {"path": str(target), "version": target.name, "warnings": warnings, "synced_to_github": False}
    finally:
        if temp is not None:
            # Created by this invocation, directly below the verified project directory.
            if temp.resolve().parent == project.resolve() and temp.name.startswith(".pending-"):
                shutil.rmtree(temp)
        lock.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    v = sub.add_parser("validate")
    v.add_argument("plan")
    s = sub.add_parser("save")
    s.add_argument("plan")
    s.add_argument("--archive", required=True)
    s.add_argument("--document", required=True)
    s.add_argument("--pdf", required=True)
    s.add_argument("--change", required=True)
    s.add_argument("--unlock", action="append", default=[], help="Only after explicit user approval for this segment")
    s.add_argument("--reference", action="append", default=[], help="Only necessary, explicitly selected reference images")
    args = parser.parse_args()
    try:
        if args.command == "validate":
            errors, warnings = validate(read_json(args.plan))
            print(json.dumps({"errors": errors, "warnings": warnings, "scope": "structure only; semantic and rendered-media review still required"}, ensure_ascii=False, indent=2))
            return int(bool(errors))
        print(json.dumps(save(args.plan, args.archive, args.document, args.pdf, args.change, args.unlock, args.reference), ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
