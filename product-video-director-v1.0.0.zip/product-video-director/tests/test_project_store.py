import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

MODULE = Path(__file__).resolve().parents[1] / "scripts" / "project_store.py"
spec = importlib.util.spec_from_file_location("project_store", MODULE)
store = importlib.util.module_from_spec(spec)
spec.loader.exec_module(store)


def fixture():
    return {"schema_version": "1.0", "project_id": "test-cup", "title": "测试杯", "brief": {"product_facts": ["白杯"]}, "assets": [{"id": "P01", "role": "产品身份"}], "segments": [
        {"id": "C01", "status": "locked", "purpose": "揭示", "duration_seconds": 5,
         "scene": {"name": "白色桌面", "source_kind": "new"},
         "start_state": {"cup": "中央静止"}, "end_state": {"cup": "中央静止"},
         "frames": {"first": {"prompt": "首帧：白色杯子位于桌面中央，把手朝右，左侧晨光。", "reference_ids": ["P01"]}, "keys": [], "last": {"prompt": "尾帧：白色杯子仍在桌面中央，把手朝右，左侧柔光照亮杯体。", "reference_ids": ["P01"]}},
         "video_prompt": "固定机位，杯子不动，左侧光逐渐增亮，最后保持。",
         "transition_out": {"type": "end", "next_segment": None, "notes": "停留后结束"}}
    ]}


class ProjectStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.plan = fixture()
        self.p = self.root / "project.json"
        self.md = self.root / "plan.md"
        self.pdf = self.root / "plan.pdf"
        # Only a format fixture. Production PDF rendering is tested separately.
        self.pdf.write_bytes(b"%PDF-1.4\nfixture\n")

    def tearDown(self):
        self.temp.cleanup()

    def write(self):
        self.p.write_text(json.dumps(self.plan, ensure_ascii=False), encoding="utf-8")
        prompts = []
        for seg in self.plan["segments"]:
            frames = seg["frames"]
            prompts += [frames["first"]["prompt"], *[x["prompt"] for x in frames["keys"]], frames["last"]["prompt"], seg["video_prompt"]]
        self.md.write_text("\n\n".join(prompts), encoding="utf-8")

    def save(self, **kwargs):
        self.write()
        return store.save(self.p, self.root / "archive", self.md, self.pdf, "test", **kwargs)

    def test_no_forced_keyframe_count(self):
        self.assertEqual(store.validate(self.plan)[0], [])
        self.plan["segments"][0]["frames"]["keys"] = [
            {"at_seconds": t, "reason": "动作节点", "prompt": f"第{t}秒的完整可见状态", "reference_ids": ["P01"]} for t in (1, 3)
        ]
        self.assertEqual(store.validate(self.plan)[0], [])

    def test_invalid_reference_and_time_rejected(self):
        self.plan["segments"][0]["frames"]["keys"] = [{"at_seconds": 8, "reason": "测试", "prompt": "状态", "reference_ids": ["MISSING"]}]
        errors, _ = store.validate(self.plan)
        self.assertTrue(any("times" in e for e in errors))
        self.assertTrue(any("reference_ids" in e for e in errors))

    def test_append_and_locked_protection(self):
        first = self.save()
        original = (Path(first["path"]) / "project.json").read_bytes()
        self.plan["title"] = "标题更新"
        second = self.save()
        self.assertEqual(second["version"], "v0002")
        self.assertEqual((Path(first["path"]) / "project.json").read_bytes(), original)
        self.plan["segments"][0]["frames"]["last"]["prompt"] = "未经允许改变尾帧。"
        with self.assertRaisesRegex(ValueError, "Locked"):
            self.save()
        third = self.save(unlock=["C01"])
        self.assertEqual(third["version"], "v0003")
        audit = store.read_json(Path(third["path"]) / "change.json")
        self.assertEqual(audit["explicitly_unlocked"], ["C01"])
        self.assertFalse(audit["synced_to_github"])

    def test_removing_completed_segment_is_protected(self):
        old = fixture()
        old["segments"][0]["status"] = "complete"
        new = copy.deepcopy(old)
        new["segments"] = []
        self.assertEqual(store.locked_changes(old, new), ["C01"])

    def test_document_must_include_all_prompts(self):
        self.write()
        self.md.write_text("仅一个摘要", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "omits"):
            store.save(self.p, self.root / "archive", self.md, self.pdf, "test")

    def test_no_video_collection_or_path_escape(self):
        video = self.root / "input.mp4"
        video.write_bytes(b"video")
        with self.assertRaisesRegex(ValueError, "image"):
            self.save(references=[video])
        for unsafe in ("../escape", "C:/escape", "CON", "nul", "a/b"):
            self.plan["project_id"] = unsafe
            self.assertTrue(store.validate(self.plan)[0])

    def test_real_boundary_warning_and_allowed_cut(self):
        second = copy.deepcopy(self.plan["segments"][0])
        second["id"] = "C02"
        second["start_state"] = {"cup": "在空中"}
        self.plan["segments"][0]["transition_out"] = {"type": "continuous", "next_segment": "C02", "notes": "接续"}
        self.plan["segments"].append(second)
        self.assertTrue(any("states differ" in w for w in store.validate(self.plan)[1]))
        self.plan["segments"][0]["transition_out"]["type"] = "cut"
        self.assertEqual(store.validate(self.plan), ([], []))


if __name__ == "__main__":
    unittest.main()
