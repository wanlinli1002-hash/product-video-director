"""Behavioral invariants for preservation, lookup and append-only scene imports."""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("scene_library", ROOT / "scripts" / "scene_library.py")
library = importlib.util.module_from_spec(spec)
spec.loader.exec_module(library)


class SceneLibraryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "library"
        shutil.copytree(ROOT / "library", self.root)

    def tearDown(self):
        self.temp.cleanup()

    def new_scene(self, number=61):
        scene = copy.deepcopy(library.show_scene(self.root, "S01")["scene"])
        scene["id"] = f"S{number:02d}"
        scene["title"] = "测试风格舞台"
        for variant in scene["variants"]:
            variant["id"] = scene["id"] + variant["id"][3:]
        return scene

    def test_originals_are_exactly_preserved(self):
        manifest = library.read_json(self.root / "sources/manifest.json")
        seen = set()
        variants = 0
        for source in manifest["sources"]:
            raw = (self.root / source["path"]).read_bytes()
            self.assertEqual(hashlib.sha256(raw).hexdigest(), source["sha256"])
            scenes = json.loads(raw.decode("utf-8-sig"))
            for pos, original in enumerate(scenes):
                self.assertNotIn(original["id"], seen)
                seen.add(original["id"])
                record = library.show_scene(self.root, original["id"], "v001")
                self.assertEqual(record["scene"], original)
                self.assertEqual(record["provenance"]["array_index"], pos)
                self.assertEqual(record["kind"], "original")
                library.validate_scene(original)
                library.validate_tags(record["tags"])
                variants += len(original["variants"])
        self.assertEqual(seen, {f"S{x:02d}" for x in range(1, 61)})
        self.assertEqual(variants, 180)

    def test_search_is_explainable_and_handles_chinese(self):
        result = library.search_scenes(self.root, "雪山 冷暖", match="all")
        self.assertIn("S16", [s["id"] for s in result["results"]])
        for candidate in result["results"]:
            self.assertEqual(set(candidate["matched_terms"]), {"雪山", "冷暖"})
            for evidence in candidate["evidence"]:
                self.assertTrue(all(evidence["term"] in value.casefold() for value in evidence["values"]))
        self.assertEqual(library.search_scenes(self.root, "雨夜")["results"][0]["id"], "S10")

    def test_negative_checks_do_not_become_capability_matches(self):
        for query in ("防水", "耐热", "认证", "功效", "成分"):
            self.assertEqual(library.search_scenes(self.root, query)["results"], [])
        scene = self.new_scene()
        scene["checks"] = ["不防水，不能把冰景当作耐寒证明。"]
        scene["variants"][0]["adaptation"] = "不能添加抗菌功效与认证。"
        library.import_scenes(self.root, scene, "测试：否定约束")
        self.assertEqual(library.search_scenes(self.root, "防水 耐寒 抗菌 认证")["results"], [])
        with self.assertRaises(library.LibraryError):
            library.validate_tags({"moods": ["不防水"]})

    def test_import_revision_and_user_variant_never_overwrite_original(self):
        original_path = self.root / "scenes/S01/v001.json"
        original_bytes = original_path.read_bytes()
        scene = copy.deepcopy(library.show_scene(self.root, "S01")["scene"])
        scene["title"] = "用户改写的摄影棚"
        result = library.import_scenes(self.root, scene, "用户修改第一版", "user-adapted")
        self.assertEqual(result["imported"][0]["version"], "v002")
        v2_bytes = (self.root / "scenes/S01/v002.json").read_bytes()
        scene["variants"][0]["style"] = "用户新增彩虹纸艺"
        library.import_scenes(self.root, scene, "用户风格版本", "user-adapted", "user_variant")
        self.assertEqual(original_path.read_bytes(), original_bytes)
        self.assertEqual((self.root / "scenes/S01/v002.json").read_bytes(), v2_bytes)
        latest = library.show_scene(self.root, "S01")
        self.assertEqual(latest["version"], "v003")
        self.assertEqual(latest["kind"], "user_variant")
        self.assertEqual(latest["parent_version"], "v002")
        self.assertEqual(latest["provenance"]["source"], "用户风格版本")

    def test_new_scene_batch_and_single_variant_are_supported(self):
        first, second = self.new_scene(61), self.new_scene(62)
        first["variants"] = first["variants"][:1]
        receipt = library.import_scenes(self.root, [first, second], "用户批量新增")
        self.assertEqual(len(receipt["imported"]), 2)
        self.assertEqual(library.list_scenes(self.root)["total"], 62)
        self.assertEqual(library.show_scene(self.root, "S61")["scene"], first)
        self.assertEqual(library.show_scene(self.root, "S61")["kind"], "user_created")

    def test_invalid_batch_cannot_partially_commit(self):
        first, second = self.new_scene(61), self.new_scene(62)
        second["variants"][0]["id"] = "S61-A"
        before = (self.root / "index.json").read_bytes()
        with self.assertRaises(library.LibraryError):
            library.import_scenes(self.root, [first, second], "无效批量")
        self.assertEqual((self.root / "index.json").read_bytes(), before)
        self.assertFalse((self.root / "scenes/S61/v001.json").exists())

    def test_existing_unindexed_file_is_not_overwritten(self):
        extra = self.root / "scenes/S01/v002.json"
        extra.write_text("preserve me", encoding="utf-8")
        scene = library.show_scene(self.root, "S01")["scene"]
        with self.assertRaises(library.LibraryError):
            library.import_scenes(self.root, scene, "冲突测试")
        self.assertEqual(extra.read_text(encoding="utf-8"), "preserve me")
        self.assertEqual(library.show_scene(self.root, "S01")["version"], "v001")

    def test_rejects_path_traversal_and_noncanonical_ids(self):
        for bad in ("../S01", "S01/../../outside", "S001", "S00", "C:/secret"):
            with self.assertRaises(library.LibraryError):
                library.show_scene(self.root, bad)
        with self.assertRaises(library.LibraryError):
            library.safe_path(self.root, "../outside.json")
        with self.assertRaises(library.LibraryError):
            library.show_scene(self.root, "S01", "../v001")

    def test_import_lock_does_not_override_existing_lock(self):
        lock = self.root / ".import.lock"
        lock.write_text("existing", encoding="utf-8")
        with self.assertRaises(library.LibraryError):
            library.import_scenes(self.root, self.new_scene(), "并发测试")
        self.assertEqual(lock.read_text(encoding="utf-8"), "existing")


if __name__ == "__main__":
    unittest.main()
