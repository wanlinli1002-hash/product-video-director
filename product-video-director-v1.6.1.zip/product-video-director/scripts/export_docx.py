#!/usr/bin/env python3
"""Export complete Markdown to editable Word locally, using python-docx.

Supports headings, paragraphs, lists, fenced prompts, hyperlinks, simple tables,
and <!-- pagebreak -->. No network, PDF renderer, or automatic dependency install.
Existing output is protected unless --force is explicitly supplied. Render and
visually inspect the final Word document with the environment's document tools.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile


def inline(paragraph, text):
    """Keep visible link labels and destinations, and never interpret prompt code."""
    token = re.compile(r"(`+)(.*?)\1|\*\*([^*]+)\*\*|\[([^\]]+)\]\(([^\s]+)\)")
    pos = 0
    for match in token.finditer(text):
        paragraph.add_run(text[pos:match.start()])
        if match.group(1):
            paragraph.add_run(match.group(2))
        elif match.group(3):
            paragraph.add_run(match.group(3)).bold = True
        else:
            # A readable destination survives copy/paste, DOCX extraction, and print.
            paragraph.add_run(f"{match.group(4)} ({match.group(5)})")
        pos = match.end()
    paragraph.add_run(text[pos:])


def table_cells(line):
    """Split pipes outside code spans, accepting Markdown's escaped pipe."""
    text = line.strip()
    if text.startswith("|"):
        text = text[1:]
    if text.endswith("|") and not text.endswith("\\|"):
        text = text[:-1]
    cells, buf, escaped, ticks = [], [], False, False
    for char in text:
        if escaped:
            if char != "|":
                buf.append("\\")
            buf.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == "`":
            ticks = not ticks
            buf.append(char)
        elif char == "|" and not ticks:
            cells.append("".join(buf).strip())
            buf = []
        else:
            buf.append(char)
    if escaped:
        buf.append("\\")
    cells.append("".join(buf).strip())
    return cells


def configure(doc, font):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Mm, Pt, RGBColor
    section = doc.sections[0]
    section.page_width, section.page_height = Mm(210), Mm(297)
    section.top_margin = section.bottom_margin = Mm(20)
    section.left_margin = section.right_margin = Mm(20)
    for name in ["Normal", "Title", "Subtitle", *[f"Heading {n}" for n in range(1, 10)], "List Bullet", "List Number"]:
        style = doc.styles[name]
        style.font.name = font
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), font)
        style.font.underline = False
        pp = style.element.get_or_add_pPr()
        for border in list(pp.findall(qn("w:pBdr"))):
            pp.remove(border)
    normal = doc.styles["Normal"]
    normal.font.size = Pt(10.5)
    normal.paragraph_format.line_spacing = 1.15
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.widow_control = True
    for name, size in [("Title", 23), ("Heading 1", 16), ("Heading 2", 13), ("Heading 3", 11.5)]:
        style = doc.styles[name]
        style.font.size = Pt(size)
        style.font.bold = True
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(10 if name != "Title" else 0)
        style.paragraph_format.space_after = Pt(6)
    # Code is editable text that can wrap and split, with no shaded box or clipping.
    if "Prompt Text" not in doc.styles:
        from docx.enum.style import WD_STYLE_TYPE
        style = doc.styles.add_style("Prompt Text", WD_STYLE_TYPE.PARAGRAPH)
        style.base_style = normal
    style = doc.styles["Prompt Text"]
    style.font.name = font
    style.font.size = Pt(10)
    style.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), font)
    style.paragraph_format.space_after = Pt(3)
    style.paragraph_format.keep_together = False
    style.paragraph_format.keep_with_next = False
    # Allow long URL/code tokens to wrap without changing their copyable contents.
    wrap = OxmlElement("w:wordWrap")
    wrap.set(qn("w:val"), "0")
    style.element.get_or_add_pPr().append(wrap)


def add_table(doc, rows):
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Mm, Pt
    count = len(rows[0])
    if any(len(row) != count for row in rows):
        raise ValueError("Markdown table rows must have the same number of columns")
    table = doc.add_table(rows=0, cols=count)
    table.autofit = False
    # Derive widths from content, with bounded weights to prevent narrow columns.
    weights = [max(5, min(36, max(len(row[i]) for row in rows))) for i in range(count)]
    widths = [170 * w / sum(weights) for w in weights]
    for col, width in zip(table.columns, widths):
        col.width = Mm(width)
    props = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        node = OxmlElement("w:" + edge)
        for key, val in {"val": "single", "sz": "4", "color": "D9D9D9"}.items():
            node.set(qn("w:" + key), val)
        borders.append(node)
    props.append(borders)
    for index, values in enumerate(rows):
        row = table.add_row()
        if index == 0:
            row._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for n, (cell, value) in enumerate(zip(row.cells, values)):
            cell.width = Mm(widths[n])
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cell_props = cell._tc.get_or_add_tcPr()
            margins = OxmlElement("w:tcMar")
            for edge in ("top", "left", "bottom", "right"):
                node = OxmlElement("w:" + edge)
                node.set(qn("w:w"), "90")
                node.set(qn("w:type"), "dxa")
                margins.append(node)
            cell_props.append(margins)
            if index == 0:
                fill = OxmlElement("w:shd")
                fill.set(qn("w:fill"), "E8EDF0")
                cell_props.append(fill)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.space_before = Pt(3)
            p.paragraph_format.line_spacing = 1.15
            p.paragraph_format.keep_with_next = False
            if max(len(r[n]) for r in rows) <= 12:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            inline(p, value.replace("<br>", "\n").replace("<br/>", "\n").replace("<br />", "\n"))
            for run in p.runs:
                run.font.size = Pt(9.5)
                if index == 0:
                    run.bold = True
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def numbered_list(doc, start=1):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    numbering = doc.part.numbering_part.element
    abstracts = numbering.findall(qn("w:abstractNum"))
    abstract_id = max([int(a.get(qn("w:abstractNumId"))) for a in abstracts] + [-1]) + 1
    abstract = OxmlElement("w:abstractNum")
    abstract.set(qn("w:abstractNumId"), str(abstract_id))
    lvl = OxmlElement("w:lvl")
    lvl.set(qn("w:ilvl"), "0")
    for tag, val in (("start", str(start)), ("numFmt", "decimal"), ("lvlText", "%1.")):
        elem = OxmlElement("w:" + tag)
        elem.set(qn("w:val"), val)
        lvl.append(elem)
    abstract.append(lvl)
    numbering.append(abstract)
    nums = numbering.findall(qn("w:num"))
    num_id = max([int(n.get(qn("w:numId"))) for n in nums] + [0]) + 1
    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(num_id))
    aid = OxmlElement("w:abstractNumId")
    aid.set(qn("w:val"), str(abstract_id))
    num.append(aid)
    numbering.append(num)
    return num_id


def parse_markdown(doc, text):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Mm
    lines, i, fence, visible, title_used, list_id = text.splitlines(), 0, None, False, False, None
    pending_break = False
    def place_break(paragraph):
        nonlocal pending_break
        if pending_break:
            paragraph.paragraph_format.page_break_before = True
            pending_break = False
        return paragraph
    while i < len(lines):
        raw = lines[i]
        line = raw.strip()
        i += 1
        if fence:
            if re.fullmatch(re.escape(fence[0]) + "{" + str(len(fence)) + r",}\s*", line):
                fence = None
                continue
            place_break(doc.add_paragraph(raw, style="Prompt Text"))
            visible = visible or bool(raw.strip())
            continue
        opened = re.match(r"^(`{3,}|~{3,})[^`~]*$", line)
        if opened:
            fence, list_id = opened.group(1), None
            continue
        if line == "<!-- pagebreak -->":
            pending_break = visible
            list_id = None
            continue
        if not line or line.startswith("<!--"):
            continue
        if re.fullmatch(r"[-*_]{3,}", line):
            continue
        heading = re.match(r"^(#{1,6})\s+(.+?)\s*#*\s*$", line)
        if heading:
            depth = len(heading.group(1))
            style = "Title" if depth == 1 and not title_used else f"Heading {max(1, depth - 1)}"
            inline(place_break(doc.add_paragraph(style=style)), heading.group(2))
            title_used, visible, list_id = True, True, None
            continue
        if "|" in line and i < len(lines):
            separator = table_cells(lines[i])
            if separator and all(re.fullmatch(r":?-{2,}:?", c) for c in separator):
                rows = [table_cells(line)]
                i += 1
                while i < len(lines) and "|" in lines[i] and lines[i].strip():
                    rows.append(table_cells(lines[i]))
                    i += 1
                table = add_table(doc, rows)
                place_break(table.cell(0, 0).paragraphs[0])
                visible, list_id = True, None
                continue
        bullet = re.match(r"^(\s*)[-*+]\s+(.+)$", raw)
        number = re.match(r"^(\s*)(\d+)[.)]\s+(.+)$", raw)
        if bullet or number:
            nesting = len((bullet or number).group(1).expandtabs(4)) // 2
            p = place_break(doc.add_paragraph(style="List Number" if number else "List Bullet"))
            p.paragraph_format.left_indent = Mm(6 + 4 * nesting)
            p.paragraph_format.first_line_indent = Mm(-4)
            if number:
                if list_id is None:
                    list_id = numbered_list(doc, int(number.group(2)))
                numpr = p._p.get_or_add_pPr().get_or_add_numPr()
                numpr.get_or_add_ilvl().val = 0
                numpr.get_or_add_numId().val = list_id
            else:
                list_id = None
            inline(p, (number.group(3) if number else bullet.group(2)))
        else:
            list_id = None
            # Preserve line-level distinctions; prompts are never summarized.
            inline(place_break(doc.add_paragraph()), line[2:] if line.startswith("> ") else raw)
        visible = True
    if fence:
        raise ValueError("Unclosed fenced code block in Markdown")
    if not visible:
        raise ValueError("The Markdown document has no visible content")


def export_docx(source, output, title=None, font="Microsoft YaHei", force=False):
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("python-docx is required in the chosen Python environment; use available document tools if unavailable.") from exc
    source, output = Path(source).resolve(), Path(output).resolve()
    if source == output:
        raise ValueError("Input and output must be different files")
    if output.suffix.lower() != ".docx":
        raise ValueError("Output filename must end in .docx")
    if output.exists() and not force:
        raise FileExistsError("Output already exists; choose a new version or pass --force explicitly")
    doc = Document()
    configure(doc, font)
    doc.core_properties.title = title or source.stem
    doc.core_properties.author = "Product Video Director"
    doc.core_properties.subject = "Editable production plan and complete prompts"
    parse_markdown(doc, source.read_text(encoding="utf-8-sig"))
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".docx-export-", suffix=".docx", dir=output.parent)
    os.close(fd)
    temp = Path(name)
    try:
        doc.save(temp)
        if force:
            os.replace(temp, output)
        else:
            created = False
            try:
                with output.open("xb") as dest, temp.open("rb") as src:
                    created = True
                    shutil.copyfileobj(src, dest)
            except Exception:
                if created:
                    output.unlink(missing_ok=True)
                raise
        return {"output": str(output), "bytes": output.stat().st_size, "format": "docx", "visual_review_required": True}
    finally:
        temp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--title")
    parser.add_argument("--font", default="Microsoft YaHei", help="Installed CJK font family name")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    try:
        print(export_docx(args.input, args.output, args.title, args.font, args.force))
        return 0
    except Exception as exc:
        print(f"Word export failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
