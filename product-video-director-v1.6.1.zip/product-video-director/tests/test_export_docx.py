import importlib.util
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile

from docx import Document
from docx.oxml.ns import qn

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
spec = importlib.util.spec_from_file_location("export_docx", SCRIPTS / "export_docx.py")
exporter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exporter)


class WordExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "plan.md"
        self.output = self.root / "plan.docx"

    def tearDown(self):
        self.temp.cleanup()

    def export(self, text, **options):
        self.source.write_text(text, encoding="utf-8")
        return exporter.export_docx(self.source, self.output, **options)

    def test_complete_long_prompt_remains_editable_and_exact(self):
        prompt = "人物身穿黄色雨衣，手持蓝色礼盒。反光 A < B & C > D，路径 C:\\素材\\产品.png；**字面标记**与`反引号`均不更改。" * 120
        self.export("# 制作方案\n\n```text\n" + prompt + "\n第二段：保留全部细节。\n```\n")
        doc = Document(self.output)
        self.assertIn(prompt, [p.text for p in doc.paragraphs])
        self.assertIn("第二段：保留全部细节。", [p.text for p in doc.paragraphs])
        with ZipFile(self.output) as package:
            self.assertFalse(any(name.startswith("word/media/") for name in package.namelist()))
        self.assertEqual(doc.paragraphs[0].style.name, "Title")
        self.assertEqual(str(doc.styles["Title"].font.color.rgb), "000000")

    def test_real_tables_lists_links_and_pagebreaks(self):
        self.export("# 产品指南\n\n## 可复制内容\n\n| 编号 | 详细说明 |\n|---|---|\n| A | 中文内容与 A < B & C > D |\n| B | `a|b` 与 c\\|d |\n\n- 第一项\n- 第二项\n\n3. 第三项\n4. 第四项\n\n[来源](https://example.com/a?x=1&y=2)\n\n<!-- pagebreak -->\n\n最后一段。")
        doc = Document(self.output)
        self.assertEqual(len(doc.tables), 1)
        self.assertEqual(doc.tables[0].cell(1, 1).text, "中文内容与 A < B & C > D")
        self.assertEqual(doc.tables[0].cell(2, 1).text, "a|b 与 c|d")
        self.assertTrue(doc.tables[0].rows[0]._tr.find(qn("w:trPr")).find(qn("w:tblHeader")) is not None)
        self.assertEqual(sum(p.style.name == "List Bullet" for p in doc.paragraphs), 2)
        self.assertEqual(sum(p.style.name == "List Number" for p in doc.paragraphs), 2)
        self.assertTrue(any("来源 (https://example.com/a?x=1&y=2)" in p.text for p in doc.paragraphs))
        self.assertTrue(doc.paragraphs[-1].paragraph_format.page_break_before)
        self.assertFalse(doc.element.findall('.//' + qn("w:br")))
        self.assertAlmostEqual(doc.sections[0].page_width.mm, 210, delta=0.1)

    def test_overwrite_protection_and_atomic_failure(self):
        self.export("# 已完成\n\n原内容")
        before = self.output.read_bytes()
        with self.assertRaises(FileExistsError):
            self.export("替换内容")
        self.assertEqual(before, self.output.read_bytes())
        with self.assertRaisesRegex(ValueError, "Unclosed"):
            self.export("```text\n没有结束", force=True)
        self.assertEqual(before, self.output.read_bytes())
        self.export("# 更新后\n\n完整内容", force=True)
        self.assertIn("完整内容", [p.text for p in Document(self.output).paragraphs])

    def test_empty_and_malformed_table_rejected(self):
        with self.assertRaisesRegex(ValueError, "visible"):
            self.export("\n<!-- note -->\n")
        with self.assertRaisesRegex(ValueError, "same number"):
            self.export("| 标题 | 内容 |\n|---|---|\n| 缺少列 |\n")
        self.assertFalse(self.output.exists())


if __name__ == "__main__":
    unittest.main()
